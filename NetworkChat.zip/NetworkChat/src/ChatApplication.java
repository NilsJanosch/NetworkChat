import javax.swing.*;
import javax.swing.text.DefaultCaret;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.KeyAdapter;
import java.awt.event.KeyEvent;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.MulticastSocket;

public class ChatApplication extends JFrame implements ActionListener, Runnable {
    private JTextField textField;
    private JTextArea textArea;
    private JButton sendButton;
    private MulticastSocket socket;
    private InetAddress group;
    private String username;

    public ChatApplication() {
        super("Chat Application");

        // Set a dark theme manually
        UIManager.put("TextField.background", new Color(30, 30, 30));
        UIManager.put("TextField.foreground", new Color(230, 230, 230));
        UIManager.put("TextArea.background", new Color(30, 30, 30));
        UIManager.put("TextArea.foreground", new Color(230, 230, 230));
        UIManager.put("TextArea.selectionBackground", new Color(104, 93, 156));
        UIManager.put("Button.background", new Color(50, 50, 50));
        UIManager.put("Button.foreground", new Color(230, 230, 230));
        UIManager.put("Button.border", BorderFactory.createLineBorder(new Color(80, 80, 80)));
        UIManager.put("Button.focus", new Color(0, 0, 0, 0));

        this.textField = new JTextField(20);
        this.textArea = new JTextArea(5, 20);
        this.textArea.setLineWrap(true);
        this.textArea.setWrapStyleWord(true);
        DefaultCaret caret = (DefaultCaret) this.textArea.getCaret();
        caret.setUpdatePolicy(DefaultCaret.ALWAYS_UPDATE);

        JScrollPane scrollPane = new JScrollPane(this.textArea);
        this.sendButton = new JButton("Send");
        this.sendButton.addActionListener(this);
        this.textArea.setEditable(false);

        this.textField.addKeyListener(new KeyAdapter() {
            @Override
            public void keyPressed(KeyEvent e) {
                if (e.getKeyCode() == KeyEvent.VK_ENTER) {
                    sendMessage();
                }
            }
        });

        JPanel panel = new JPanel(new BorderLayout());
        panel.add(this.textField, BorderLayout.CENTER);
        panel.add(this.sendButton, BorderLayout.EAST);

        this.setLayout(new BorderLayout());
        this.add(scrollPane, BorderLayout.CENTER);
        this.add(panel, BorderLayout.SOUTH);

        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setSize(400, 300);
        this.setVisible(true);

        try {
            this.socket = new MulticastSocket(4446);
            this.group = InetAddress.getByName("230.0.0.1");
            this.socket.joinGroup(this.group);
        } catch (IOException e) {
            e.printStackTrace();
        }

        Thread thread = new Thread(this);
        thread.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        sendMessage();
    }

    private void sendMessage() {
        String message = this.textField.getText().trim();
        if (!message.isEmpty()) {
            this.textField.setText("");
            String fullMessage = this.username + ": " + message;
            byte[] buf = fullMessage.getBytes();
            DatagramPacket packet = new DatagramPacket(buf, buf.length, this.group, 4446);
            try {
                this.socket.send(packet);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        }
    }

    @Override
    public void run() {
        while (true) {
            byte[] buf = new byte[256];
            DatagramPacket packet = new DatagramPacket(buf, buf.length);
            try {
                this.socket.receive(packet);
            } catch (IOException e) {
                e.printStackTrace();
            }
            String message = new String(packet.getData(), 0, packet.getLength());
            SwingUtilities.invokeLater(() -> this.textArea.append(message + "\n"));
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            String username = JOptionPane.showInputDialog("Enter your username:");
            if (username == null || username.isEmpty()) {
                username = "Unknown";
            }
            ChatApplication chatApp = new ChatApplication();
            chatApp.username = username;
            String userJoinedMessage = username + " has joined the chat.";
            byte[] userJoinedBuf = userJoinedMessage.getBytes();
            DatagramPacket userJoinedPacket = new DatagramPacket(userJoinedBuf, userJoinedBuf.length, chatApp.group, 4446);
            try {
                chatApp.socket.send(userJoinedPacket);
            } catch (IOException ex) {
                ex.printStackTrace();
            }
        });
    }
}
